<?php $__env->startSection('title', 'View a player'); ?>
<?php $__env->startSection('content'); ?>

<div class="container col-md-8 col-md-offset-2">
<div class="well well bs-component" style="opacity: 0.7;">
<div class="content">
<h2 style="font-weight: bold;"> <b><?php echo $player->name; ?> </b></h2>

<h3><b><?php echo $player->team; ?> </b></h3>	
<h4>Position: <?php echo $player->position; ?> </h4>
<h4> Age: <?php echo $player->age; ?> | Height: <?php echo $player->height; ?>(cm) </h4>
<h4> Goals: <?php echo $player->goal; ?> | Assist: <?php echo $player->assist; ?> </h4>
</div><br>
<a href="<?php echo action('PlayersController@edit', $player->slug); ?>" class="btn btn-info pull-left">Edit</a>
<form method="post" action="<?php echo action('PlayersController@delete', $player->slug); ?>" class="pull-left">
<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
<div>
<button type="submit" class="btn btn-danger">Delete</button>
</div>
</form>
<div class="clearfix"></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>