<?php $__env->startSection('title', 'View a team'); ?>
<?php $__env->startSection('content'); ?>

<div class="container col-md-8 col-md-offset-2">
<div class="well well bs-component" style="opacity: 0.7;">
<div class="content">
<h2> <?php echo $team->name; ?></h2>
<h3> Group <?php echo $team->group_no; ?> </h3>
<h4>Coach: <?php echo $team->coach; ?> <br> Matches Played: <?php echo $team->match_played; ?> <br>Goals Scored: <?php echo $team->goals; ?>

<br>FIFA Ranking: <?php echo $team->ranking; ?> | WorldCup won: <?php echo $team->cup_win; ?> times</h4>

<h3 style="text-align: left;"><b>Players</b></h3>
<?php if($players->isEmpty()): ?>
			<p> No Player.</p>
<?php else: ?>
<table class="table">
	<tbody>
		<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('PlayersController@show', $player->slug); ?>"><?php echo $player->name; ?></td>
			<td><?php echo $player->position; ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>