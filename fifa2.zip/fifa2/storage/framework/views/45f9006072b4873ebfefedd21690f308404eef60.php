<?php $__env->startSection('title', 'Players'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container col-md-8 col-md-offset-2">
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Players </h2>
			</div>
		<?php if($players->isEmpty()): ?>
			<p> No Player.</p>
		<?php else: ?>
		<table class="table" style="font-size: 19px;">
			<!--<thead>
			<tr>
				<th>Player Name</th>
				<th>Team</th>
				<th>Position</th>
			</tr>
		</thead>-->
	<tbody>
		<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('PlayersController@show', $player->slug); ?>"><?php echo $player->name; ?></a> <br> <p style="font-size: 15px;"><?php echo $player->position; ?></p></td>
			<td><?php echo $player->team; ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>