<?php $__env->startSection('title', 'Stadiums'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container col-md-8 col-md-offset-2">
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Stadiums </h2>
			</div>
		<?php if($stadiums->isEmpty()): ?>
			<p> No Stadium.</p>
		<?php else: ?>
		<table class="table" style="font-size: 18px;">
			<!--<thead>
			<tr>
				<th>Stadium ID</th>
				<th>Stadium Name</th>
				<th>City</th>
			</tr>
		</thead>-->
	<tbody>
		<?php $__currentLoopData = $stadiums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stadium): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr style="text-align: center;">
			
			<td><a href="<?php echo action('StadiumsController@show', $stadium->slug); ?>"><?php echo $stadium->name; ?></a></td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>