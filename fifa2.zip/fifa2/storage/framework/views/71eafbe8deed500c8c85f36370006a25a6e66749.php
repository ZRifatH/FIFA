<?php $__env->startSection('title', 'edit a player'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container col-md-8 col-md-offset-2">
        <div class="well well bs-component">
            <form class="form-horizontal" method="post">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="alert alert-danger"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                <fieldset>
                    <legend>Edit Player</legend>
                    <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Name</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="name" placeholder="Name" name="name" value="<?php echo $player->name; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Age</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="age" placeholder="Age" name="age" value="<?php echo $player->age; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Height</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="height" placeholder="Height(in cm)" name="height" value="<?php echo $player->height; ?>">
                            </div>
                        </div>

                         <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Team</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="team" placeholder="Player Team" name="team" value="<?php echo $player->team; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Team ID</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="team_id" placeholder="Team ID" name="team_id" value="<?php echo $player->team_id; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Position</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="position" placeholder="Player Position" name="position" value="<?php echo $player->position; ?>">
                            </div>
                        </div>

                           <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Goals Scored</label>
                            <div class="col-lg-10">
                                <input type="number" class="form-control" id="goal" placeholder="Goal" name="goal" value="<?php echo $player->goal; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                        <label for="title" class="col-lg-2 control-label">Assists</label>
                            <div class="col-lg-10">
                                <input type="text" class="form-control" id="assist" placeholder="Assist" name="assist" value="<?php echo $player->assist; ?>">
                            </div>
                        </div>

                  
                    <div class="form-group">
                    <label>
                    <input type="checkbox" name="status" <?php echo $player->status?"":"checked"; ?>> Close this player?
                    </label>
                    </div>

                    <div class="form-group">
<div class="col-lg-10 col-lg-offset-2">
<button class="btn btn-default">Cancel</button>
<button type="submit" class="btn btn-primary">Update</button>
</div>
</div>
                </fieldset>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>