<?php $__env->startSection('title', 'Matches'); ?>
<?php $__env->startSection('content'); ?>

<div style="text-align: right; margin-right:40px;">
	<h4><a href="filter" style="text-decoration: none; color: white; font-size: 20px;">Filter Matches</a></h4>
	<div class="container col-md-8 col-md-offset-2">
		<div class="panel panel-default" style="opacity: 0.7;" >
			<div class="panel-heading">
				<h2> Matches </h2>
			</div>

			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php endif; ?>

		<?php if($matches->isEmpty()): ?>
			<p> No Match.</p>
		<?php else: ?>
		<table class="table">
			<!--<thead>
			<tr>
				<th>Match ID</th>
				<th>Team1</th>
				<th>Team2</th>
				<th>Winner</th>
				<th>Stadium</th>
				<th>Goal1</th>
				<th>Goal2</th>
				<th>Match Date</th>
				<th>Match Time</th>
			</tr>
		</thead>-->
	<tbody>
		<?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
	
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>">Match <?php echo $match->id; ?> </a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td>-</td>
			<td><?php echo $match->goal2; ?></td>
			<td><?php echo $match->team2; ?></td>
			<!--<td><?php echo $match->stadium; ?></td>
			<td><?php echo $match->match_date; ?></td>
			<td><?php echo $match->match_time; ?></td>-->

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php endif; ?>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>