<?php $__env->startSection('title', 'View a stadium'); ?>
<?php $__env->startSection('content'); ?>

<div class="container col-md-8 col-md-offset-2">
<div class="well well bs-component" style="opacity: 0.8;">
<div class="content">
<h3><b> <?php echo $stadium->name; ?></b> <br><?php echo $stadium->city; ?> </h3>
<h4> Capacity: <?php echo $stadium->capacity; ?> <br> Matches Played: <?php echo $stadium->match_played; ?> </h4>
<h3 style="text-align: left;"><b>Matches</b></h3>
<?php if($matches->isEmpty()): ?>
			<p> No Match.</p>
<?php else: ?>
<table class="table">
	<tbody>
		<?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>">Match <?php echo $match->id; ?></a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td>-</td>
			<td><?php echo $match->goal2; ?></td>
			<td><?php echo $match->team2; ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php endif; ?>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>