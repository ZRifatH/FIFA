<?php $__env->startSection('title', 'View a match'); ?>
<?php $__env->startSection('content'); ?>

<div class="container col-md-8 col-md-offset-2">
<div class="well well bs-component"  style="opacity: 0.7;">
<div class="content">
	
<h2> <?php echo $match->team1; ?> &nbsp <b><?php echo $match->goal1; ?> - <?php echo $match->goal2; ?></b> &nbsp <?php echo $match->team2; ?></h2>
<h3><b><?php echo $match->stadium; ?> <br></h3>
<h4><?php echo $match->match_type; ?> match </b></h4>
<h4><b>Match Time: <?php echo $match->match_date; ?> | <?php echo $match->match_time; ?></b></h4>
		
</div><br>
<a href="<?php echo action('MatchesController@edit', $match->slug); ?>" class="btn btn-info pull-left">Edit</a>
<form method="post" action="<?php echo action('MatchesController@delete', $match->slug); ?>" class="pull-left">
<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
<div>
<button type="submit" class="btn btn-danger">Delete</button>
</div>
</form>
<div class="clearfix"></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>