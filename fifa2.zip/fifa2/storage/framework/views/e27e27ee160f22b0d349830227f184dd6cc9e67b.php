<?php $__env->startSection('title', 'Teams'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container col-md-8 col-md-offset-2">
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Teams </h2>
			</div>
		<?php if($teams->isEmpty()): ?>
			<p> No Team.</p>
		<?php else: ?>
		<table class="table" style="text-align: center; font-size: 19px;">
			<!--<thead>
			<tr>
				<th>Team Name</th>
				<th>Group</th>
			</tr>
		</thead>-->
	<tbody>
		<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('TeamsController@show', $team->slug); ?>"><?php echo $team->name; ?></a><br>Group <?php echo $team->group_no; ?></td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>