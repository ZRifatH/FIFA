<?php $__env->startSection('title', 'Filtered matches'); ?>
<?php $__env->startSection('content'); ?>
	
<div class="container col-md-8 col-md-offset-2"><br>
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Group Phase </h2>
			</div>
		<?php if($groups->isEmpty()): ?>
			<p> No match.</p>
		<?php else: ?>
		<table class="table">
		<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>" style="text-decoration: none;">Match <?php echo $match->id; ?> </a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td> - </td>
			<td><?php echo $match->goal2; ?> &nbsp&nbsp</td>
			<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $match->team2; ?></td>
			<!--<td><?php echo $match->stadium; ?></td>
			<td><?php echo $match->date; ?></td>
			<td><?php echo $match->time; ?></td>-->
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
</div>
</div>

	<div class="container col-md-8 col-md-offset-2"><br>
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Knockout Phase </h2>
			</div>
		<?php if($knockouts->isEmpty()): ?>
			<p> No match.</p>
		<?php else: ?>
		<table class="table">
		<?php $__currentLoopData = $knockouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>" style="text-decoration: none;">Match <?php echo $match->id; ?> </a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td> - </td>
			<td><?php echo $match->goal2; ?> &nbsp&nbsp</td>
			<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $match->team2; ?></td>
			<!--<td><?php echo $match->stadium; ?></td>
			<td><?php echo $match->date; ?></td>
			<td><?php echo $match->time; ?></td>-->
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
</div>
</div>
<br>

<div class="container col-md-8 col-md-offset-2"><br>
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Quarter-Finals </h2>
			</div>
		<?php if($quarters->isEmpty()): ?>
			<p> No match.</p>
		<?php else: ?>
		<table class="table">
		<?php $__currentLoopData = $quarters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>" style="text-decoration: none;">Match <?php echo $match->id; ?> </a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td> - </td>
			<td><?php echo $match->goal2; ?> &nbsp&nbsp</td>
			<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $match->team2; ?></td>
			<!--<td><?php echo $match->stadium; ?></td>
			<td><?php echo $match->date; ?></td>
			<td><?php echo $match->time; ?></td>-->
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
</div>
</div>

<div class="container col-md-8 col-md-offset-2"><br>
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Semi-Finals </h2>
			</div>
		<?php if($semifinals->isEmpty()): ?>
			<p> No match.</p>
		<?php else: ?>
		<table class="table">
		<?php $__currentLoopData = $semifinals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>" style="text-decoration: none;">Match <?php echo $match->id; ?> </a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td> - </td>
			<td><?php echo $match->goal2; ?> &nbsp&nbsp</td>
			<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $match->team2; ?></td>
			<!--<td><?php echo $match->stadium; ?></td>
			<td><?php echo $match->date; ?></td>
			<td><?php echo $match->time; ?></td>-->
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
</div>
</div>
<br>

<div class="container col-md-8 col-md-offset-2"><br>
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Play-off for third place </h2>
			</div>
		<?php if($playoffs->isEmpty()): ?>
			<p> No match.</p>
		<?php else: ?>
		<table class="table">
		<?php $__currentLoopData = $playoffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>" style="text-decoration: none;">Match <?php echo $match->id; ?> </a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td> - </td>
			<td><?php echo $match->goal2; ?> &nbsp&nbsp</td>
			<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $match->team2; ?></td>
			<!--<td><?php echo $match->stadium; ?></td>
			<td><?php echo $match->date; ?></td>
			<td><?php echo $match->time; ?></td>-->
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
</div>
</div>
<br>

<div class="container col-md-8 col-md-offset-2"><br>
		<div class="panel panel-default" style="opacity: 0.7;">
			<div class="panel-heading">
				<h2> Final </h2>
			</div>
		<?php if($finals->isEmpty()): ?>
			<p> No match.</p>
		<?php else: ?>
		<table class="table">
		<?php $__currentLoopData = $finals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><a href="<?php echo action('MatchesController@show', $match->slug); ?>" style="text-decoration: none;">Match <?php echo $match->id; ?> </a></td>
			<td><?php echo $match->team1; ?></td>
			<td><?php echo $match->goal1; ?></td>
			<td> - </td>
			<td><?php echo $match->goal2; ?> &nbsp&nbsp</td>
			<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $match->team2; ?></td>
			<!--<td><?php echo $match->stadium; ?></td>
			<td><?php echo $match->date; ?></td>
			<td><?php echo $match->time; ?></td>-->
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>