<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use App\Stadium;
use App\Match;
use Illuminate\Foundation\Testing\RefreshDatabase;

/*class StadiumTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    /*public function testExample()
    {
        $stadium = new Stadium(['name'=>'Test']);
        $this->assertEquals('Test', $stadium->name);
    }
}*/
