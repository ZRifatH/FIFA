<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use App\Stadium;
use App\Player;
use App\Match;
use App\Team;

use Illuminate\Foundation\Testing\RefreshDatabase;

class FifaTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */

    public function testCountStadium()
	{
    	$this->assertEquals(12, Stadium::count());
    }

    public function testDb()
    {
    	$stadium = Stadium::first();
   		$this->assertEquals($stadium['name'], $stadium->name);
    	$this->assertEquals($stadium['city'], $stadium->city);
	}
    
    public function testPlayerName()
    {
        $player = new Player(['name'=>'Lionel Messi']);
	    $this->assertEquals('Lionel Messi', $player->name);
    }
    public function testPlayerNameCaseSensitivity()
    {
        $player = new Player(['name'=>'lionel Messi']);
	    $this->assertNotEquals('Lionel Messi', $player->name);
    }
    public function testPlayerNameBlank()
    {
        $player = new Player(['name'=>'']);
	    $this->assertNotEquals('Lionel Messi', $player->name);
    }

    public function testPlayerAge()
    {
        $player = new Player(['age'=>'31']);
        $this->assertEquals('31', $player->age);
    }
}
